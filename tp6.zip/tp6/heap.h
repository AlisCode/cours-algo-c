void entasser(int tas[], int val);
void detasser(int tas[]);
void permuter(int tas[], int index_a, int index_b);
void afficher(int tas[]);
